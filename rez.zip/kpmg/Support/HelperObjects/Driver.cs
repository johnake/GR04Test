﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium;

namespace kpmg.Support.HelperObjects
{
    public class Driver
    {
        public static IWebDriver CurrentDriver { get; set; }
    }
}
